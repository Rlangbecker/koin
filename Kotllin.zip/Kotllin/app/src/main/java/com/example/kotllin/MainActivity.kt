package com.example.kotllin

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.koin.android.ext.android.inject
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import org.koin.dsl.module

class MainActivity : AppCompatActivity() {

    data class Pizza(val name: String, val ingredients: List<Ingredient>)

    data class Ingredient(val name: String)


    private val pizzaService: PizzaService by inject()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializa o Koin
        startKoin {
            androidContext(this@MainActivity)
            modules(appModule)
        }

        val pizza = pizzaService.makePizza("Pizza Especial")
        val pizzaNameTextView = findViewById<TextView>(R.id.pizzaNameTextView)
        val pizzaIngredientsTextView = findViewById<TextView>(R.id.pizzaIngredientsTextView)

        pizzaNameTextView.text = "Pedido: ${pizza.name}"
        pizzaIngredientsTextView.text = "Ingredientes: ${pizza.ingredients.joinToString(", ")}"
    }
}


class PizzaService(private val ingredients: List<Ingredient>) {
    fun makePizza(pizzaName: String): Pizza {
        val pizzaIngredients = ingredients.shuffled().take(3)
        return Pizza(pizzaName, pizzaIngredients)
    }
}

val appModule = module {
    single { PizzaService(get()) }
    single {
        listOf(
            Ingredient("Queijo"),
            Ingredient("Tomate"),
            Ingredient("Presunto"),
            Ingredient("Cogumelos")
        )
    }
}
