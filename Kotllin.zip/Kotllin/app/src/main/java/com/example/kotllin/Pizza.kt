package com.example.kotllin

data class Pizza(val name: String, val ingredients: List<Ingredient>)

data class Ingredient(val name: String)